/**
 * Created by BALASUBRAMANIAM on 06-01-2015.
 */

var db;
var request = window.indexedDB.open("Employee1234", 1);

request.onerror = function(event) {
    console.log("error: ");
};

request.onsuccess = function(event) {
    db = request.result;
    console.log("success: "+ db);
};

request.onupgradeneeded=function(evt)
{
    db=evt.target.result;
    var objectStore = db.createObjectStore("employees", {keyPath: "id"});
};

function AddData() {
    drand = Math.round(Math.random(1000)*1000,0);

    var rname=document.getElementById("name");
    var rphoto=document.getElementById("photo");
    console.log(rphoto.value);


    var request = db.transaction(["employees"], "readwrite")
        .objectStore("employees")
        .add({id:drand , name: rname.value, photo:rphoto.value});

    request.onsuccess = function (event) {
        alert(rname.value+"has been added to your database.");
    };

    request.onerror = function (event) {
        alert("Unable to add data\r\n"+rname.value+"is aready exist in your database! ");
    }
}
function readAll() {
    var objectStore = db.transaction("employees").objectStore("employees");

    objectStore.openCursor().onsuccess = function(event) {
        var cursor = event.target.result;
        if (cursor) {
            alert("Name for id " + cursor.key + " is " + cursor.value.name);
            cursor.continue();
        }
        else {
            alert("No more entries!");
        }
    };
}










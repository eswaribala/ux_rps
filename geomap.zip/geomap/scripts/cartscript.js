/**
 * Created by BALASUBRAMANIAM on 06-01-2015.
 */
function AddData()
{
    if(localStorage.getItem("qty")!=null)
    {
        // alert(localStorage.getItem("qty"));
        var result=document.getElementById("data");
        localStorage.setItem("qty",parseInt(localStorage.getItem("qty"))+1);
        result.innerText=localStorage.getItem("qty");
    }
    else
    {
        localStorage.setItem("qty",1);
    }

}
function SubData()
{
    if(localStorage.getItem("qty")!=null)
    {
        // alert(localStorage.getItem("qty"));
        var result=document.getElementById("data");
        localStorage.setItem("qty",parseInt(localStorage.getItem("qty"))-1);
        result.innerText=localStorage.getItem("qty");
    }


}

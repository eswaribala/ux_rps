/**
 * Created by BALASUBRAMANIAM on 20-01-2015.
 */
$(document).ready(function(){

    var url = 'https://maps.googleapis.com/maps/api/place/search/json';

    jQuery.ajax({
        url: url,
        dataType: 'jsonp',
        type: 'GET',
        data:  {
            location: '33.787794,-117.853111',
            radius: 1000,
            name: 'coffee',
            key: 'your_key', // add your key here
            sensor: 'false'
        },

        // on success
        success: function(data, textStatus, jqXHR){

            console.log(data);


        },

        // on failure
        error: function (jqXHR, textStatus, errorThrown){
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        }
    });
});
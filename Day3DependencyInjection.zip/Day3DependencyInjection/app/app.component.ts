/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import {Component} from '@angular/core';
import {Http} from '@angular/http';
import 'rxjs/Rx';

@Component({
    selector: 'user-data',
    templateUrl:'app/app.component.html'
})

export class UserComponent {
    private users = [];
    exists = false;
    httpObj;


    constructor(http: Http) {
        this.httpObj=http;

    }

    CallRest()
    {
       
            this.httpObj.get('http://jsonplaceholder.typicode.com/users/')
                .flatMap((data) => data.json())
                .subscribe((data) => {
                    this.users.push(data);
                });
        
    }
    generateArray(obj){
        return Object.keys(obj).map((key)=>{ return obj[key]});
    }

    toggleExists()
    {
      this.exists=!this.exists;
      if(this.exists)
          this.CallRest();
      else
          this.users=[];
    }
}
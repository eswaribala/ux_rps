/**
 * Created by BALASUBRAMANIAM on 01-07-2017.
 */
reactapp=angular.module('ReactApp',['react']);

reactapp.controller('reactController',['$scope',
    function($scope)
{

$scope.obj={

    "userName":"Param",
    "password":"test@123"

}

}])
//create react component
var Hello = React.createClass( {
    propTypes: {
        userName: React.PropTypes.string.isRequired,
        password: React.PropTypes.string.isRequired
    },

    render: function() {
        return React.DOM.span( null,
            'Hello ' + this.props.userName + ' ' +
            this.props.password
        );
    }
} );


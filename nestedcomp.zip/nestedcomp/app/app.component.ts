import {Component} from '@angular/core';

@Component({
    selector: 'first-comp',
    template: `
        <h1>{{message}}</h1>
        <div>
        <button (click)="decrement()">
            Decrement
        </button>
        <input type="text" [value]="count">
        <button (click)="increment()">
        Increment
        </button>
        </div>

    `
})
export class AppComponent {


    message: string = 'angular 2 from property!';

    count: number = 0;
    increment() {
        this.count++;
    }
    decrement() {
        this.count--;
    }
}

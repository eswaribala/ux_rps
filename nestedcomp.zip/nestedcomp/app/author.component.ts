/**
 * Created by BALASUBRAMANIAM on 30-06-2017.
 */
import {Component} from '@angular/core';

@Component({
    selector: 'author-comp',
    template: `
<div>
    <p>{{authorName}}</p>

</div>
`
})
export class AuthorComponent {


    authorName: string = 'Goenka!';



}

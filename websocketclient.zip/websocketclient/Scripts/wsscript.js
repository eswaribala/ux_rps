/**
 * Created by BALASUBRAMANIAM on 12-01-2015.
 */

var webSocket =
    new WebSocket('ws://localhost/WebSocketHandlerTest/Handler.ashx');

webSocket.onopen=function(event)
{
    document.getElementById('message').innerHTML="TESCO connection established";
}
webSocket.onmessage=function(event)
{
    document.getElementById('message').innerHTML+="<p>"+event.data+"</p>";
}

function Start()
{
    info = document.getElementById("data");
    webSocket.send(info.value);
}

function Stop()
{
    webSocket.close();
}
webSocket.onclose = function(event)
{
    document.getElementById('message').innerHTML+="Connection Closed";
}
import { Component ,Input} from '@angular/core';
import {bootstrap} from 'angular2/platform/browser';

@Component({
  selector: 'app-root',
  template: '<b>Bootstrapping an Angular 2 application{{user}}!</b>'
})
export class AppComponent {
    @Input() user: string;
    ngOnInit() {
        console.log('This if the value for user: ' + this.user);
    }

}
/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { Component, OnChange } from '@angular/core';

@Component({
    selector: 'button-click',
    templateUrl: 'events/event.component.html'
})
export class AppComponent implements OnChange {
    num = 0;
    visitorCount = 0;

    ngOnChange(val: number) {
        this.visitorCount = val;
        this.num=val+10;
    }
}

/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';

import { AppComponent } from './event.component';
import { CounterComponent } from './visitor.component';
import { InterestComponent } from './event.interestComponent';
import { CalculatorComponent } from './calculator.component';

@NgModule({
    imports: [BrowserModule],
    declarations: [
        AppComponent,
        CounterComponent,
        InterestComponent,
        CalculatorComponent
    ],

    bootstrap: [ InterestComponent ],
})
export class AppModule {
}

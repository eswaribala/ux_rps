/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
    selector: 'calculate',
    templateUrl: 'events/calculator.component.html'
})
export class CalculatorComponent {
    @Input()  IPrincipal = 0;
    @Input()  IROI = 0.00;
    @Input()  IYear = 0;
    @Output() result = new EventEmitter<number>();

    calculate() {
        //this.count++;
        this.result.emit(this.IPrincipal,this.IROI,this.IYear);
    }
}
